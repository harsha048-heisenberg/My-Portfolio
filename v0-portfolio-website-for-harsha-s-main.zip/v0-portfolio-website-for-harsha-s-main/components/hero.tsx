"use client"

import { useEffect, useState } from "react"

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20 px-4 bg-black">
      <div className="max-w-6xl mx-auto w-full">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-center">
            {/* Profile Image - Cyberpunk style with neon glow frame */}
            <div className="flex-shrink-0 order-2 md:order-1">
              <div className="relative w-full aspect-square max-w-sm mx-auto">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-purple-900 to-cyan-600 neon-glow" />
                <div className="absolute inset-2 bg-black border-2 border-cyan-500" />
                <div className="absolute inset-4 bg-black border-2 border-purple-500 flex items-center justify-center overflow-hidden">
                  <img
                    src="/images/design-mode/Untitled%20design.png"
                    alt="Harsha S"
                    className="w-full h-full object-contain"
                  />
                </div>
              </div>
            </div>

            {/* Content - Bold typography with cyberpunk colors */}
            <div className="flex-1 order-1 md:order-2 space-y-8">
              <div className="space-y-4">
                <h1 className="text-7xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 leading-none">
                  HARSHA S
                </h1>
                <p className="text-2xl md:text-3xl font-bold text-cyan-400 border-l-4 border-purple-500 pl-6">
                  COMPUTER SCIENCE STUDENT, DATA SCIENCE AND ML ENTHUSIAST
                </p>
              </div>

              <p className="text-lg md:text-xl text-gray-300 leading-relaxed max-w-xl font-medium">
                Analytical and motivated Computer Science student with strong foundations in{" "}
                <span className="font-black text-cyan-400">PYTHON</span>,{" "}
                <span className="font-black text-purple-400">MACHINE LEARNING</span>, and{" "}
                <span className="font-black text-cyan-400">DATA SCIENCE</span>. Experienced in developing data-driven
                solutions using tools like <span className="font-black text-purple-400">XGBoost</span>,{" "}
                <span className="font-black text-cyan-400">Streamlit</span>, and Tkinter. Passionate about deriving
                insights from complex data and solving real-world business problems through analytical thinking.
                Demonstrated teamwork and leadership through active roles in IEEE and internships with IBM and
                Microsoft. Eager to begin my career contributing to data-driven decision making and business analytics
                innovation.
              </p>

              <div className="flex flex-wrap gap-4 pt-8">
                <button
                  onClick={() => scrollToSection("portfolio")}
                  className="px-8 py-4 bg-gradient-to-r from-purple-600 to-cyan-600 text-white border-2 border-cyan-400 font-black text-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-200 active:scale-95 neon-glow"
                >
                  VIEW PORTFOLIO
                </button>
                <button
                  onClick={() => scrollToSection("contact")}
                  className="px-8 py-4 bg-transparent text-cyan-400 border-2 border-purple-500 font-black text-lg hover:bg-purple-900/30 hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-200 active:scale-95"
                >
                  CONTACT ME
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
