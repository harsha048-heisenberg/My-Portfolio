"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import { Brain, Zap, BarChart3, Code2 } from "lucide-react"

interface Service {
  icon: React.ReactNode
  title: string
  description: string
}

const services: Service[] = [
  {
    icon: <Brain size={40} />,
    title: "Machine Learning",
    description: "Building intelligent ML models and AI solutions for real-world problems",
  },
  {
    icon: <Code2 size={40} />,
    title: "AI Solutions",
    description: "Developing AI applications that transform data into actionable insights",
  },
  {
    icon: <BarChart3 size={40} />,
    title: "Data Analysis",
    description: "Analyzing complex datasets and creating meaningful visualizations",
  },
  {
    icon: <Zap size={40} />,
    title: "Optimization",
    description: "Optimizing algorithms and systems for maximum efficiency",
  },
]

export default function Services() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="services" ref={sectionRef} className="py-24 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="mb-20 border-b-8 border-black pb-8">
          <h2 className="text-7xl md:text-8xl font-black text-black">SERVICES</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="group bg-white border-6 border-black p-8 hover:bg-black hover:text-white transition-all duration-300 h-full">
                <div className="w-20 h-20 border-4 border-black flex items-center justify-center text-black mb-6 group-hover:text-white group-hover:border-white transition-all duration-300">
                  {service.icon}
                </div>

                <h3 className="text-2xl font-black text-black group-hover:text-white mb-4">{service.title}</h3>
                <p className="text-base leading-relaxed group-hover:text-gray-200">{service.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
