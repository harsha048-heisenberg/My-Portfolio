"use client"

import { useEffect, useRef, useState } from "react"

interface EducationItem {
  title: string
  school: string
  period: string
}

interface WorkItem {
  title: string
  company: string
  period: string
  description: string
}

interface SkillItem {
  name: string
  percentage: number
}

const educationData: EducationItem[] = [
  {
    title: "B.E. in Computer Science",
    school: "Jawaharlal Nehru New College of Engineering",
    period: "2022 - 2026 | GPA: 8.87/10",
  },
  {
    title: "PU in Science",
    school: "Vikasa Pre-University College",
    period: "2020 - 2022 | GPA: 90.66%",
  },
  {
    title: "High School",
    school: "S.K.N. English School",
    period: "2010 - 2020 | GPA: 95.04%",
  },
]

const workData: WorkItem[] = [
  {
    title: "AI & ML Intern",
    company: "Microsoft & Edunet Foundation",
    period: "April 2025 - May 2025",
    description: "Developed movie recommendation system using MovieLens20M, SVD, and Thinter",
  },
  {
    title: "Cybersecurity Intern",
    company: "IBM SkillsBuild & Edunet Foundation",
    period: "January 2025 - February 2025",
    description: "Built secure data hiding tool with Python, OpenCV, and Thinter",
  },
]

const skillsData: SkillItem[] = [
  { name: "Python", percentage: 90 },
  { name: "Java", percentage: 75 },
  { name: "C", percentage: 70 },
  { name: "SQL", percentage: 85 },
  { name: "XGBoost", percentage: 80 },
  { name: "Artificial Intelligence", percentage: 85 },
  { name: "Machine Learning", percentage: 90 },
  { name: "Graphical Designing", percentage: 75 },
  { name: "Streamlit", percentage: 85 },
  { name: "Tkinter", percentage: 80 },
  { name: "CSS", percentage: 75 },
  { name: "HTML", percentage: 80 },
  { name: "Effective Communication", percentage: 85 },
  { name: "Quick Learning Ability", percentage: 90 },
]

export default function About() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="about" ref={sectionRef} className="py-24 px-4 bg-black text-white">
      <div className="max-w-6xl mx-auto">
        <div className="mb-20 border-b-8 border-white pb-8">
          <h2 className="text-7xl md:text-8xl font-black">ABOUT</h2>
        </div>

        {/* Education and Work Experience */}
        <div className="grid md:grid-cols-2 gap-12 mb-20">
          {/* Education */}
          <div
            className={`transition-all duration-700 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
            }`}
          >
            <h3 className="text-4xl font-black mb-8 border-l-8 border-yellow-400 pl-6">EDUCATION</h3>
            <div className="space-y-6">
              {educationData.map((edu, index) => (
                <div
                  key={index}
                  className="border-4 border-white p-6 hover:bg-white hover:text-black transition-all duration-200"
                >
                  <h4 className="font-black text-xl mb-2">{edu.title}</h4>
                  <p className="text-sm mb-2 opacity-80">{edu.school}</p>
                  <p className="text-sm font-bold">{edu.period}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Work Experience */}
          <div
            className={`transition-all duration-700 delay-200 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
            }`}
          >
            <h3 className="text-4xl font-black mb-8 border-l-8 border-yellow-400 pl-6">EXPERIENCE</h3>
            <div className="space-y-6">
              {workData.map((work, index) => (
                <div
                  key={index}
                  className="border-4 border-white p-6 hover:bg-white hover:text-black transition-all duration-200"
                >
                  <h4 className="font-black text-xl mb-2">{work.title}</h4>
                  <p className="text-sm mb-2 opacity-80">{work.company}</p>
                  <p className="text-sm font-bold mb-3">{work.period}</p>
                  <p className="text-sm">{work.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Skills */}
        <div
          className={`transition-all duration-700 delay-300 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h3 className="text-4xl font-black mb-8 border-l-8 border-yellow-400 pl-6">SKILLS</h3>
          <div className="border-4 border-white p-8">
            <div className="grid md:grid-cols-2 gap-8">
              {skillsData.map((skill, index) => (
                <div key={index} className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-black text-lg">{skill.name}</span>
                    <span className="font-black text-yellow-400">{skill.percentage}%</span>
                  </div>
                  <div className="w-full bg-white h-4 border-2 border-white overflow-hidden">
                    <div
                      className="bg-yellow-400 h-full transition-all duration-1000"
                      style={{
                        width: isVisible ? `${skill.percentage}%` : "0%",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
