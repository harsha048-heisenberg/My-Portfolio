"use client"

import { useState } from "react"
import { useEffect, useRef } from "react"
import { Award } from "lucide-react"

interface Certification {
  id: number
  title: string
  organization: string
  date: string
}

const defaultCertifications: Certification[] = [
  {
    id: 1,
    title: "Microsoft Azure AI Document Intelligence",
    organization: "Online course on Microsoft's AI Document Intelligence",
    date: "2025",
  },
  {
    id: 2,
    title: "Cyber Threat Intelligence 101",
    organization: "An introduction to Cyber Threat Intelligence by ArcX",
    date: "2025",
  },
  {
    id: 3,
    title: "Data Science Job Simulation",
    organization: "Job simulation for a Cybersecurity Analyst role by BCG X in collaboration with Forage",
    date: "2025",
  },
  {
    id: 4,
    title: "Cybersecurity Fundamentals",
    organization: "Fundamentals covering key cybersecurity concepts and practices, a course provided by IBM",
    date: "2025",
  },
  {
    id: 5,
    title: "ICIP: Critical Infrastructure Protection",
    organization: "Completed an online course on critical infrastructure protection offered by OPSWAT Academy",
    date: "2025",
  },
  {
    id: 6,
    title: "Cybersecurity Analyst Job Simulation",
    organization: "Job simulation for a Cybersecurity Analyst role by Tata in collaboration with Forage",
    date: "2025",
  },
]

export default function Certifications() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="certifications" ref={sectionRef} className="py-24 px-4 bg-black text-white">
      <div className="max-w-6xl mx-auto">
        <div className="mb-20 border-b-8 border-white pb-8">
          <h2 className="text-7xl md:text-8xl font-black">CERTIFICATIONS</h2>
        </div>

        {/* Certifications Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {defaultCertifications.map((cert, index) => (
            <div
              key={cert.id}
              className={`transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="group h-full flex flex-col bg-black border-6 border-white overflow-hidden hover:bg-white hover:text-black transition-all duration-300">
                {/* Content */}
                <div className="flex-grow p-8 flex flex-col">
                  <div className="flex items-start justify-between mb-4">
                    <Award className="flex-shrink-0" size={28} />
                  </div>

                  <h3 className="text-2xl font-black mb-3">{cert.title}</h3>
                  <p className="text-base mb-4 opacity-90">{cert.organization}</p>
                  <p className="text-sm font-bold mt-auto pt-6 border-t-4 border-white">{cert.date}</p>

                  {/* Badge */}
                  <div className="mt-4">
                    <span className="inline-block bg-yellow-400 text-black text-xs font-black px-4 py-2">VERIFIED</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
