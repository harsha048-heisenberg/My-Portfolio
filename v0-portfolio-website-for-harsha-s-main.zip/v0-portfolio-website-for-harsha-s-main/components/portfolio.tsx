"use client"

import { useEffect, useRef, useState } from "react"
import { Github } from "lucide-react"

interface Project {
  id: number
  title: string
  description: string
  tools: string[]
  date: string
  codeLink?: string
}

const projects: Project[] = [
  {
    id: 1,
    title: "AI-Powered Dream Symbol Interpreter",
    description:
      "Project to interpret dreams based on symbols. Developed an AI-Powered Dream Symbol Interpreter using Streamlit, TF-IDF, XGBoost, and Mistral AI",
    tools: ["Streamlit", "TF-IDF", "XGBoost", "Mistral AI"],
    date: "06/2025",
    codeLink: "#",
  },
  {
    id: 2,
    title: "Bengaluru Flood Risk Dashboard",
    description:
      "Project aimed at assessing flood risk in Bengaluru. Created a Bengaluru Flood Risk Dashboard utilizing Streamlit, Folium, and Random Forest",
    tools: ["Streamlit", "Folium", "Random Forest"],
    date: "06/2025",
    codeLink: "#",
  },
  {
    id: 3,
    title: "Movie Recommendation System",
    description: "Project focused on recommending movies to users. Built using MovieLens20M Dataset and Tkinter",
    tools: ["MovieLens20M", "Tkinter", "Python"],
    date: "2025",
    codeLink: "#",
  },
  {
    id: 4,
    title: "Secure Data Hiding in Images using Steganography",
    description:
      "Developed steganography technique for message encryption. Implemented a secure data hiding in images using Steganography with Python and OpenCV",
    tools: ["Steganography", "Python", "OpenCV"],
    date: "02/2025",
    codeLink: "#",
  },
]

export default function Portfolio() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="portfolio" ref={sectionRef} className="py-24 px-4 bg-black text-white">
      <div className="max-w-6xl mx-auto">
        <div className="mb-20 border-b-8 border-white pb-8">
          <h2 className="text-7xl md:text-8xl font-black">PROJECTS</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={project.id}
              className={`transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="group h-full flex flex-col bg-black border-6 border-white overflow-hidden hover:bg-white hover:text-black transition-all duration-300">
                {/* Content */}
                <div className="flex-grow p-8 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-2xl font-black flex-grow">{project.title}</h3>
                    <span className="text-xs font-black bg-yellow-400 text-black px-4 py-2 whitespace-nowrap ml-2">
                      {project.date}
                    </span>
                  </div>

                  <p className="text-base mb-6 flex-grow opacity-90">{project.description}</p>

                  {/* Tools */}
                  <div className="flex flex-wrap gap-2 mb-6 border-t-4 border-white pt-6">
                    {project.tools.map((tool) => (
                      <span key={tool} className="text-xs font-black bg-yellow-400 text-black px-3 py-2">
                        {tool}
                      </span>
                    ))}
                  </div>

                  {/* Links - Only CODE button */}
                  <div className="flex gap-6 pt-4 border-t-4 border-white">
                    {project.codeLink && (
                      <a
                        href={project.codeLink}
                        className="flex items-center gap-2 text-sm font-black hover:text-yellow-400 transition-colors"
                      >
                        <Github size={18} />
                        CODE
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
