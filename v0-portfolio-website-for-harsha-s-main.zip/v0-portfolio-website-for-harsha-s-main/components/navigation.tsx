"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"

interface NavigationProps {
  scrolled: boolean
}

export default function Navigation({ scrolled }: NavigationProps) {
  const [mobileOpen, setMobileOpen] = useState(false)

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    element?.scrollIntoView({ behavior: "smooth" })
    setMobileOpen(false)
  }

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? "bg-background/80 backdrop-blur-md border-b border-border" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Harsha S
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8">
            {["home", "about", "services", "projects", "certifications", "contact"].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item === "projects" ? "portfolio" : item)}
                className="capitalize text-sm font-medium hover:text-primary transition-colors"
              >
                {item}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden pb-4 space-y-2">
            {["home", "about", "services", "projects", "certifications", "contact"].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item === "projects" ? "portfolio" : item)}
                className="block w-full text-left capitalize text-sm font-medium hover:text-primary transition-colors py-2"
              >
                {item}
              </button>
            ))}
          </div>
        )}
      </div>
    </nav>
  )
}
